C-Play Dome Showcase
====================

An example presentation for C-Play v2.4 and newer.

1. Keep this folder together (the presentation refers to media/ by relative path).
2. In C-Play, open the Slides panel and click "Open a saved presentation".
3. Pick Dome-Showcase.cplaypres and press Next (or the right arrow) to step through.

Every slide has presenter notes describing what it shows.
All media in this folder was generated for this example and may be reused freely.
Rebuild it with tools/example-presentation/make_dome_showcase.py in the C-Play repository.
